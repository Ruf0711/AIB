/**
 * app.js
 * Wires UI to TensorFlow.js models:
 *   - CNN classifier  (original MNIST classifier)
 *   - MaxPool denoising autoencoder
 *   - AvgPool denoising autoencoder
 */
'use strict';

/* ── State ───────────────────────────────────────── */
var classifier  = null;   // CNN classifier
var maxDenoiser = null;   // autoencoder with MaxPooling
var avgDenoiser = null;   // autoencoder with AveragePooling

var trainXs = null, trainYs = null;
var valXs   = null, valYs   = null;
var testXs  = null, testYs  = null;

var busyCls = false;
var busyAE  = false;

/* ── DOM helpers ─────────────────────────────────── */
var $ = function(id) { return document.getElementById(id); };

function log(msg, color) {
  var span = document.createElement('span');
  span.style.color = color || '#8b949e';
  span.textContent = msg + '\n';
  $('log').appendChild(span);
  $('log').scrollTop = $('log').scrollHeight;
}

function setStatus(html) { $('status').innerHTML = html; }

function setBar(id, pct) { $(id).style.width = pct + '%'; }

// Enable/disable Test5 button: needs test data + at least one denoiser
function refreshTest5() {
  $('btn-t5').disabled = !(testXs && (maxDenoiser || avgDenoiser));
}

/* ── CNN Classifier ──────────────────────────────── */
function buildClassifier(lr) {
  var m = tf.sequential();
  m.add(tf.layers.conv2d({filters:32, kernelSize:3, activation:'relu',
    padding:'same', inputShape:[28,28,1]}));
  m.add(tf.layers.conv2d({filters:64, kernelSize:3, activation:'relu', padding:'same'}));
  m.add(tf.layers.maxPooling2d({poolSize:[2,2]}));
  m.add(tf.layers.dropout({rate:0.25}));
  m.add(tf.layers.flatten());
  m.add(tf.layers.dense({units:128, activation:'relu'}));
  m.add(tf.layers.dropout({rate:0.5}));
  m.add(tf.layers.dense({units:10, activation:'softmax'}));
  m.compile({optimizer:tf.train.adam(lr),
    loss:'categoricalCrossentropy', metrics:['accuracy']});
  return m;
}

/* ── Denoising Autoencoder ───────────────────────────────────────────────
   Architecture:  Encoder → Bottleneck (7×7) → Decoder → 28×28 output

   ENCODER
     Conv2D(32) + BN → Pool  →  28×28 → 14×14
     Conv2D(64) + BN → Pool  →  14×14 →  7×7

   DECODER
     Conv2D(64) + BN → UpSampling2D  →  7×7  → 14×14
     Conv2D(32) + BN → UpSampling2D  → 14×14 → 28×28
     Conv2D(1,  sigmoid)              → output [0,1]

   The ONLY difference between the two models is the pooling layer type:
     poolType='max'  →  MaxPooling2D  (preserves bright strokes, sharper)
     poolType='avg'  →  AveragePooling2D (averages patches, softer/blurrier)

   BatchNormalization after each Conv prevents the model from collapsing
   to a trivial all-grey output (which caused the black canvas bug).

   Loss: MSE between noisy INPUT and clean TARGET.
──────────────────────────────────────────────────────────────────────── */
function buildAutoencoder(poolType) {
  var m = tf.sequential();

  // ── Encoder block 1  28×28 → 14×14 ──
  m.add(tf.layers.conv2d({filters:32, kernelSize:3, activation:'relu',
    padding:'same', inputShape:[28,28,1]}));
  m.add(tf.layers.batchNormalization());

  if (poolType === 'max') {
    m.add(tf.layers.maxPooling2d({poolSize:[2,2], padding:'same'}));
  } else {
    m.add(tf.layers.averagePooling2d({poolSize:[2,2], padding:'same'}));
  }

  // ── Encoder block 2  14×14 → 7×7 (bottleneck) ──
  m.add(tf.layers.conv2d({filters:64, kernelSize:3, activation:'relu', padding:'same'}));
  m.add(tf.layers.batchNormalization());

  if (poolType === 'max') {
    m.add(tf.layers.maxPooling2d({poolSize:[2,2], padding:'same'}));
  } else {
    m.add(tf.layers.averagePooling2d({poolSize:[2,2], padding:'same'}));
  }

  // ── Decoder block 1  7×7 → 14×14 ──
  m.add(tf.layers.conv2d({filters:64, kernelSize:3, activation:'relu', padding:'same'}));
  m.add(tf.layers.batchNormalization());
  m.add(tf.layers.upSampling2d({size:[2,2]}));

  // ── Decoder block 2  14×14 → 28×28 ──
  m.add(tf.layers.conv2d({filters:32, kernelSize:3, activation:'relu', padding:'same'}));
  m.add(tf.layers.batchNormalization());
  m.add(tf.layers.upSampling2d({size:[2,2]}));

  // ── Output: 1 channel, sigmoid → pixel values in [0,1] ──
  m.add(tf.layers.conv2d({filters:1, kernelSize:3, activation:'sigmoid', padding:'same'}));

  m.compile({optimizer:tf.train.adam(0.001), loss:'meanSquaredError'});
  return m;
}

/* ── Render model summary table ─────────────────── */
function showModelInfo(m, title) {
  if (!m) { $('minfo').textContent = 'No model.'; return; }
  var total = 0;
  var rows = m.layers.map(function(l, i) {
    var p = 0;
    l.getWeights().forEach(function(w){ p += w.size; });
    total += p;
    return '<tr><td>['+i+']</td><td>'+l.name+'</td>' +
      '<td>'+JSON.stringify(l.outputShape)+'</td>' +
      '<td style="text-align:right">'+p.toLocaleString()+'</td></tr>';
  }).join('');
  $('minfo').innerHTML =
    '<div style="color:#58a6ff;margin-bottom:6px;font-weight:700">'+title+'</div>' +
    '<table><thead><tr style="color:#8b949e;font-size:10px">' +
    '<td>#</td><td>Layer</td><td>Output</td><td style="text-align:right">Params</td>' +
    '</tr></thead><tbody>'+rows+'</tbody>' +
    '<tfoot><tr style="border-top:1px solid #30363d">' +
    '<td colspan="3" style="color:#58a6ff;padding-top:6px">Total</td>' +
    '<td style="text-align:right;color:#58a6ff;padding-top:6px">'+total.toLocaleString()+'</td>' +
    '</tr></tfoot></table>';
}

/* ════════════════════════════════════════════════
   HANDLER: Load Data
════════════════════════════════════════════════ */
async function onLoad() {
  var tf_ = $('f-train').files[0];
  var te_  = $('f-test').files[0];
  if (!tf_ || !te_) {
    setStatus('<span class="er">⚠ Select both CSV files first.</span>');
    return;
  }

  $('btn-load').disabled = true;
  $('log').textContent   = '';
  setStatus('⏳ Parsing CSV files…');
  log('Reading train file: ' + tf_.name);

  try {
    // Dispose previous tensors
    [trainXs,trainYs,valXs,valYs,testXs,testYs].forEach(function(t){ if(t) t.dispose(); });
    trainXs=trainYs=valXs=valYs=testXs=testYs=null;

    var tr = await loadTrainFromFiles(tf_);
    log('Loaded ' + tr.xs.shape[0] + ' training images.');

    var vs   = parseFloat($('hp-vs').value) || 0.1;
    var spl  = splitTrainVal(tr.xs, tr.ys, vs);
    tr.xs.dispose(); tr.ys.dispose();

    trainXs = spl.trainXs; trainYs = spl.trainYs;
    valXs   = spl.valXs;   valYs   = spl.valYs;

    log('Reading test file: ' + te_.name);
    var te = await loadTestFromFiles(te_);
    testXs = te.xs; testYs = te.ys;
    log('Loaded ' + testXs.shape[0] + ' test images.');

    var ntr = trainXs.shape[0], nv = valXs.shape[0], nte = testXs.shape[0];
    setStatus('<span class="ok">✓ Ready</span> — train: <b>'+ntr+'</b> · val: <b>'+nv+'</b> · test: <b>'+nte+'</b>');
    log('Split: '+ntr+' train / '+nv+' val / '+nte+' test');

    $('btn-train').disabled = false;
    $('btn-ae').disabled    = false;
    refreshTest5();

  } catch(e) {
    setStatus('<span class="er">✗ '+e.message+'</span>');
    log('ERROR: '+e.message, '#f85149');
    console.error(e);
  }

  $('btn-load').disabled = false;
}

/* ════════════════════════════════════════════════
   HANDLER: Train Classifier
════════════════════════════════════════════════ */
async function onTrainClassifier() {
  if (!trainXs) { log('Load data first.', '#f85149'); return; }
  if (busyCls)  { log('Already training.', '#f85149'); return; }

  var epochs = parseInt($('hp-ep').value)  || 5;
  var batch  = parseInt($('hp-bs').value)  || 64;
  var lr     = parseFloat($('hp-lr').value)|| 0.001;

  busyCls = true;
  $('btn-train').disabled = true;
  $('btn-eval').disabled  = true;
  $('btn-t5').disabled    = true;
  setBar('bar-cls', 0);
  $('log').textContent = '';

  try {
    if (classifier) { classifier.dispose(); }
    classifier = buildClassifier(lr);
    log('Classifier built — lr='+lr+', epochs='+epochs+', batch='+batch);
    showModelInfo(classifier, 'CNN Classifier');

    var cb = tfvis.show.fitCallbacks(
      {name:'Classifier', tab:'Training'},
      ['loss','val_loss','acc','val_acc'],
      {height:180, callbacks:['onEpochEnd']}
    );

    var t0 = Date.now();
    await classifier.fit(trainXs, trainYs, {
      epochs: epochs,
      batchSize: batch,
      shuffle: true,
      validationData: [valXs, valYs],
      callbacks: {
        onEpochEnd: async function(ep, logs) {
          setBar('bar-cls', Math.round((ep+1)/epochs*100));
          log('Epoch '+(ep+1)+'/'+epochs+
            ' — acc: '+(logs.acc*100).toFixed(2)+
            '% | val_acc: '+(logs.val_acc*100).toFixed(2)+'%');
          await tf.nextFrame();
        },
        onEpochEnd: cb.onEpochEnd,
        onBatchEnd: cb.onBatchEnd
      }
    });

    log('✓ Classifier done in '+((Date.now()-t0)/1000).toFixed(1)+'s', '#3fb950');
    $('btn-eval').disabled   = false;
    $('btn-sv-cls').disabled = false;

  } catch(e) {
    log('ERROR: '+e.message, '#f85149');
    console.error(e);
  }

  busyCls = false;
  $('btn-train').disabled = false;
  refreshTest5();
  setBar('bar-cls', 100);
}

/* ════════════════════════════════════════════════
   HANDLER: Evaluate Classifier
════════════════════════════════════════════════ */
async function onEvaluate() {
  if (!classifier || !testXs) { log('Need classifier + test data.', '#f85149'); return; }
  $('btn-eval').disabled = true;
  log('Evaluating…');

  try {
    var result = tf.tidy(function() {
      var logits = classifier.predict(testXs);
      var pred   = logits.argMax(-1);
      var tru    = testYs.argMax(-1);
      var acc    = pred.equal(tru).mean().arraySync();
      return {
        pred: Array.from(pred.dataSync()),
        tru:  Array.from(tru.dataSync()),
        acc:  acc
      };
    });

    var pct = (result.acc * 100).toFixed(2);
    $('acc').innerHTML = '<div class="num">'+pct+'%</div>' +
      '<div class="sub">Test Accuracy ('+testXs.shape[0]+' samples)</div>';
    log('Test accuracy: '+pct+'%', '#3fb950');

    // Confusion matrix
    var N = 10;
    var cm = []; for(var i=0;i<N;i++){cm.push(new Array(N).fill(0));}
    var ct = new Array(N).fill(0);
    var cc = new Array(N).fill(0);
    for(var i=0;i<result.tru.length;i++){
      var t=result.tru[i], p=result.pred[i];
      cm[t][p]++; ct[t]++;
      if(t===p) cc[t]++;
    }

    await tfvis.render.confusionMatrix(
      {name:'Confusion Matrix', tab:'Evaluation'},
      {values:cm, tickLabels:['0','1','2','3','4','5','6','7','8','9']}
    );
    await tfvis.render.barchart(
      {name:'Per-Class Accuracy', tab:'Evaluation'},
      ['0','1','2','3','4','5','6','7','8','9'].map(function(c,i){
        return {index:c, value: ct[i]>0 ? cc[i]/ct[i] : 0};
      }),
      {xLabel:'Digit', yLabel:'Accuracy', height:220}
    );
    log('Charts in Visor (Toggle Visor button).', '#8b949e');

  } catch(e) {
    log('ERROR: '+e.message, '#f85149');
  }

  $('btn-eval').disabled = false;
}

/* ════════════════════════════════════════════════
   HANDLER: Train Both Denoisers

   Step 1 (HW): add Gaussian noise to test/train images.
   Step 2 (HW): train CNN autoencoder for denoising.

   We add noise to the TRAINING images to create
   (noisy → clean) pairs, then train on MSE loss.
   Two separate models: MaxPool and AvgPool.
════════════════════════════════════════════════ */
async function onTrainDenoisers() {
  if (!trainXs) { log('Load data first.', '#f85149'); return; }
  if (busyAE)   { log('Already training.', '#f85149'); return; }

  var epochs = parseInt($('ae-ep').value)    || 15;
  var batch  = parseInt($('ae-bs').value)    || 128;
  var sigma  = parseFloat($('sl-noise').value) || 0.3;

  busyAE = true;
  $('btn-ae').disabled = true;
  setBar('bar-ae', 0);
  $('log').textContent = '';

  log('Denoiser training — σ='+sigma+', epochs='+epochs+', batch='+batch);
  log('Tip: need ≥ 15 epochs for visible denoising. loss target < 0.02', '#8b949e');

  try {
    /* ── Step 1: Add noise to training images ─────────────────────────
       noisy_trainXs  = trainXs + N(0, σ)  clipped to [0,1]
       The model learns:  noisy_trainXs → trainXs   (remove the noise)
       Input  = noisy image
       Target = clean image
       Loss   = MSE (mean squared error per pixel)
    ─────────────────────────────────────────────────────────────────── */
    log('Step 1: Generating noisy training images (σ='+sigma+')…');
    var noisyXs = addNoise(trainXs, sigma);
    log('Noisy tensor shape: '+JSON.stringify(noisyXs.shape));

    var total = epochs * 2;

    /* ── Step 2a: Train MaxPool Autoencoder ───────────────────────────
       MaxPooling2D: takes the MAXIMUM value in each 2×2 window.
       → preserves the brightest (most prominent) features
       → reconstruction tends to be sharper and higher contrast
    ─────────────────────────────────────────────────────────────────── */
    log('\n── MaxPool Autoencoder ──');
    if (maxDenoiser) maxDenoiser.dispose();
    maxDenoiser = buildAutoencoder('max');

    var cbMax = tfvis.show.fitCallbacks(
      {name:'MaxPool Loss', tab:'Denoiser'},
      ['loss','val_loss'],
      {height:160, callbacks:['onEpochEnd']}
    );

    var lossMax = 1.0;
    await maxDenoiser.fit(noisyXs, trainXs, {
      epochs: epochs,
      batchSize: batch,
      shuffle: true,
      validationSplit: 0.1,
      callbacks: {
        onEpochEnd: async function(ep, logs) {
          lossMax = logs.loss;
          setBar('bar-ae', Math.round((ep+1)/total*100));
          log('[MaxPool] '+(ep+1)+'/'+epochs+
            ' loss='+logs.loss.toFixed(5)+
            ' val='+logs.val_loss.toFixed(5));
          await tf.nextFrame();
        },
        onEpochEnd: cbMax.onEpochEnd,
        onBatchEnd: cbMax.onBatchEnd
      }
    });

    log('✓ MaxPool done. Final loss: '+lossMax.toFixed(5),
      lossMax < 0.05 ? '#3fb950' : '#d29922');
    if (lossMax > 0.05) log('  ⚠ Loss > 0.05: try 20+ epochs', '#d29922');

    $('bdg-max').textContent  = '✓ MaxPool';
    $('bdg-max').className    = 'badge bm';
    $('btn-sv-max').disabled  = false;

    /* ── Step 2b: Train AvgPool Autoencoder ───────────────────────────
       AveragePooling2D: takes the MEAN of each 2×2 window.
       → smooths features, loses sharp edges
       → reconstruction tends to be softer and blurrier
       (compare with MaxPool to see the difference clearly)
    ─────────────────────────────────────────────────────────────────── */
    log('\n── AvgPool Autoencoder ──');
    if (avgDenoiser) avgDenoiser.dispose();
    avgDenoiser = buildAutoencoder('avg');

    var cbAvg = tfvis.show.fitCallbacks(
      {name:'AvgPool Loss', tab:'Denoiser'},
      ['loss','val_loss'],
      {height:160, callbacks:['onEpochEnd']}
    );

    var lossAvg = 1.0;
    await avgDenoiser.fit(noisyXs, trainXs, {
      epochs: epochs,
      batchSize: batch,
      shuffle: true,
      validationSplit: 0.1,
      callbacks: {
        onEpochEnd: async function(ep, logs) {
          lossAvg = logs.loss;
          setBar('bar-ae', Math.round((epochs+ep+1)/total*100));
          log('[AvgPool] '+(ep+1)+'/'+epochs+
            ' loss='+logs.loss.toFixed(5)+
            ' val='+logs.val_loss.toFixed(5));
          await tf.nextFrame();
        },
        onEpochEnd: cbAvg.onEpochEnd,
        onBatchEnd: cbAvg.onBatchEnd
      }
    });

    log('✓ AvgPool done. Final loss: '+lossAvg.toFixed(5),
      lossAvg < 0.05 ? '#3fb950' : '#d29922');
    if (lossAvg > 0.05) log('  ⚠ Loss > 0.05: try 20+ epochs', '#d29922');

    $('bdg-avg').textContent  = '✓ AvgPool';
    $('bdg-avg').className    = 'badge ba';
    $('btn-sv-avg').disabled  = false;

    noisyXs.dispose(); // free GPU memory
    showModelInfo(maxDenoiser, 'MaxPool Denoiser (same arch for AvgPool)');
    log('\n✓ Both denoisers ready. Click Test 5.', '#3fb950');

  } catch(e) {
    log('ERROR: '+e.message, '#f85149');
    console.error(e);
  }

  busyAE = false;
  $('btn-ae').disabled = false;
  refreshTest5();
  setBar('bar-ae', 100);
}

/* ════════════════════════════════════════════════
   HANDLER: Test 5 Random  (Step 3 HW)

   Displays a 3-row × 5-column grid:
     Row 1 — Noisy:   test image + Gaussian noise
     Row 2 — MaxPool: maxDenoiser.predict(noisy)
     Row 3 — AvgPool: avgDenoiser.predict(noisy)
════════════════════════════════════════════════ */
async function onTest5() {
  if (!testXs || !testYs) { log('Load test data first.', '#f85149'); return; }
  if (!maxDenoiser && !avgDenoiser) {
    log('Train or load denoisers first.', '#f85149'); return;
  }

  var sigma = parseFloat($('sl-noise').value) || 0.3;
  var K = 5;

  $('preview').innerHTML = '';

  // --- Sample 5 random test images ---
  var batch = getRandomTestBatch(testXs, testYs, K);
  var clean = batch.batchXs;                              // [5,28,28,1]
  var trueL = Array.from(batch.batchYs.argMax(-1).dataSync()); // [5]
  batch.batchYs.dispose();

  // --- Add noise to the 5 test images ---
  var noisy = addNoise(clean, sigma);                     // [5,28,28,1]

  // --- Classifier predictions (optional) ---
  var predL = null;
  if (classifier) {
    predL = Array.from(
      tf.tidy(function() { return classifier.predict(clean).argMax(-1); })
        .dataSync()
    );
  }

  // --- Denoiser outputs ---
  var maxOut = maxDenoiser ? maxDenoiser.predict(noisy) : null; // [5,28,28,1]
  var avgOut = avgDenoiser ? avgDenoiser.predict(noisy) : null; // [5,28,28,1]

  // --- Build the 3-row grid ---
  var grid = document.createElement('div');
  grid.className = 'pg';

  // Renders one complete row (label cell + 5 image cells)
  // Uses a closure factory to correctly capture index `idx` in the loop
  function addRow(rowLabel, rowCls, srcTensor, cvCls, showPred, showTrue) {
    // Column 0: row label
    var lbl       = document.createElement('div');
    lbl.className = 'row-lbl ' + rowCls;
    lbl.textContent = rowLabel;
    grid.appendChild(lbl);

    // Columns 1-5: one canvas per image
    for (var i = 0; i < K; i++) {
      // IIFE to correctly capture `i` per iteration
      (function(idx) {
        var cell       = document.createElement('div');
        cell.className = 'pcell';

        var cv       = document.createElement('canvas');
        cv.className = cvCls;

        // Slice the idx-th image out of the [5,28,28,1] batch
        // squeeze() → [28,28,1], reshape → [784] for draw function
        var imgT = tf.tidy(function() {
          return srcTensor
            .slice([idx, 0, 0, 0], [1, 28, 28, 1])
            .squeeze()
            .reshape([784]);
        });
        draw28x28ToCanvas(imgT, cv, 4);
        imgT.dispose();

        cell.appendChild(cv);

        // Classifier label under noisy row
        if (showPred && predL !== null) {
          var isOk   = (predL[idx] === trueL[idx]);
          var plDiv  = document.createElement('div');
          plDiv.className   = 'pl ' + (isOk ? 'ok' : 'er');
          plDiv.textContent = predL[idx];
          cell.appendChild(plDiv);
        }

        // True label caption
        if (showTrue) {
          var sub       = document.createElement('div');
          sub.className = 'psub';
          sub.textContent = 'true: ' + trueL[idx];
          cell.appendChild(sub);
        }

        grid.appendChild(cell);
      })(i); // immediately invoke with current i
    }
  }

  function addEmptyRow(rowLabel, rowCls) {
    var lbl       = document.createElement('div');
    lbl.className = 'row-lbl ' + rowCls;
    lbl.textContent = rowLabel;
    grid.appendChild(lbl);
    for (var i = 0; i < K; i++) {
      var c       = document.createElement('div');
      c.className = 'pcell';
      c.innerHTML = '<span style="font-size:10px;color:#8b949e">not loaded</span>';
      grid.appendChild(c);
    }
  }

  // Row 1: noisy input images
  addRow('Noisy',   'rn', noisy,  'cn', true,  true);

  // Row 2: MaxPool reconstruction
  if (maxOut) addRow('MaxPool', 'rm', maxOut, 'cm', false, false);
  else        addEmptyRow('MaxPool', 'rm');

  // Row 3: AvgPool reconstruction
  if (avgOut) addRow('AvgPool', 'ra', avgOut, 'ca', false, false);
  else        addEmptyRow('AvgPool', 'ra');

  $('preview').appendChild(grid);

  // --- Dispose all temporary tensors ---
  clean.dispose();
  noisy.dispose();
  if (maxOut) maxOut.dispose();
  if (avgOut) avgOut.dispose();
}

/* ════════════════════════════════════════════════
   HANDLER: Save / Load Models  (Step 4 HW)
   Save downloads .json + .weights.bin to disk.
   Load reads them back via tf.io.browserFiles().
════════════════════════════════════════════════ */
async function onSaveCls() {
  if (!classifier) return;
  try { await classifier.save('downloads://mnist-cnn');
    log('✓ Saved: mnist-cnn.json + weights.bin', '#3fb950'); }
  catch(e){ log('Save error: '+e.message,'#f85149'); }
}

async function onSaveMax() {
  if (!maxDenoiser) return;
  try { await maxDenoiser.save('downloads://denoiser-max');
    log('✓ Saved: denoiser-max.json + weights.bin', '#58a6ff'); }
  catch(e){ log('Save error: '+e.message,'#f85149'); }
}

async function onSaveAvg() {
  if (!avgDenoiser) return;
  try { await avgDenoiser.save('downloads://denoiser-avg');
    log('✓ Saved: denoiser-avg.json + weights.bin', '#d29922'); }
  catch(e){ log('Save error: '+e.message,'#f85149'); }
}

async function onLoadCls() {
  var jf = $('f-cls-json').files[0];
  var bf = $('f-cls-bin').files[0];
  if (!jf || !bf) { log('Select model.json AND weights.bin', '#f85149'); return; }
  try {
    if (classifier) classifier.dispose();
    classifier = await tf.loadLayersModel(tf.io.browserFiles([jf, bf]));
    log('✓ Classifier loaded.', '#3fb950');
    showModelInfo(classifier, 'Classifier (loaded)');
    $('btn-eval').disabled   = !testXs;
    $('btn-sv-cls').disabled = false;
    $('btn-train').disabled  = !trainXs;
    refreshTest5();
  } catch(e){ log('Load error: '+e.message,'#f85149'); console.error(e); }
}

async function onLoadDenoisers() {
  var mj = $('f-mx-json').files[0], mb = $('f-mx-bin').files[0];
  var aj = $('f-av-json').files[0], ab = $('f-av-bin').files[0];
  if (!mj||!mb||!aj||!ab) {
    log('Select all 4 denoiser files (2 × .json + 2 × .bin)', '#f85149'); return;
  }
  try {
    log('Loading MaxPool denoiser…');
    if (maxDenoiser) maxDenoiser.dispose();
    maxDenoiser = await tf.loadLayersModel(tf.io.browserFiles([mj, mb]));
    $('bdg-max').textContent = '✓ MaxPool'; $('bdg-max').className = 'badge bm';
    $('btn-sv-max').disabled = false;
    log('✓ MaxPool loaded.', '#58a6ff');

    log('Loading AvgPool denoiser…');
    if (avgDenoiser) avgDenoiser.dispose();
    avgDenoiser = await tf.loadLayersModel(tf.io.browserFiles([aj, ab]));
    $('bdg-avg').textContent = '✓ AvgPool'; $('bdg-avg').className = 'badge ba';
    $('btn-sv-avg').disabled = false;
    log('✓ AvgPool loaded.', '#d29922');

    showModelInfo(maxDenoiser, 'MaxPool Denoiser (loaded)');
    log('Both denoisers ready. Click Test 5.', '#3fb950');
    refreshTest5();
  } catch(e){ log('Load error: '+e.message,'#f85149'); console.error(e); }
}

/* ── Reset ───────────────────────────────────────── */
function onReset() {
  if (busyCls || busyAE) { log('Wait for training to finish.','#f85149'); return; }

  [trainXs,trainYs,valXs,valYs,testXs,testYs].forEach(function(t){ if(t) t.dispose(); });
  trainXs=trainYs=valXs=valYs=testXs=testYs=null;

  if (classifier)  { classifier.dispose();  classifier  = null; }
  if (maxDenoiser) { maxDenoiser.dispose(); maxDenoiser = null; }
  if (avgDenoiser) { avgDenoiser.dispose(); avgDenoiser = null; }

  $('log').textContent = 'Reset.';
  $('status').innerHTML = 'Select both CSV files, then click Load.';
  $('acc').innerHTML = '<div class="num">—</div><div class="sub">Test Accuracy</div>';
  $('preview').innerHTML =
    '<span style="color:#8b949e;font-size:12px">Steps: Load Data → Train Classifier → Train Both Denoisers → Test 5</span>';
  $('minfo').textContent = 'No model yet.';
  $('bar-cls').style.width = '0';
  $('bar-ae').style.width  = '0';
  $('bdg-max').textContent = '○ MaxPool'; $('bdg-max').className = 'badge';
  $('bdg-avg').textContent = '○ AvgPool'; $('bdg-avg').className = 'badge';

  ['btn-train','btn-eval','btn-t5','btn-sv-cls',
   'btn-ae','btn-sv-max','btn-sv-avg'].forEach(function(id){ $(id).disabled=true; });
  $('btn-load').disabled = false;

  // Clear file inputs
  ['f-train','f-test','f-cls-json','f-cls-bin',
   'f-mx-json','f-mx-bin','f-av-json','f-av-bin'].forEach(function(id){ $(id).value=''; });
  [['fn-train','mnist_train.csv'],['fn-test','mnist_test.csv'],
   ['fn-cls-json','model.json'],['fn-cls-bin','weights.bin'],
   ['fn-mx-json','denoiser-max.json'],['fn-mx-bin','denoiser-max.weights.bin'],
   ['fn-av-json','denoiser-avg.json'],['fn-av-bin','denoiser-avg.weights.bin']
  ].forEach(function(p){ $(p[0]).textContent = p[1]; });
}

/* ── Wire buttons ────────────────────────────────── */
$('btn-load').onclick    = onLoad;
$('btn-train').onclick   = onTrainClassifier;
$('btn-eval').onclick    = onEvaluate;
$('btn-t5').onclick      = onTest5;
$('btn-sv-cls').onclick  = onSaveCls;
$('btn-ld-cls').onclick  = onLoadCls;
$('btn-ae').onclick      = onTrainDenoisers;
$('btn-sv-max').onclick  = onSaveMax;
$('btn-sv-avg').onclick  = onSaveAvg;
$('btn-ld-ae').onclick   = onLoadDenoisers;
$('btn-visor').onclick   = function(){ tfvis.visor().toggle(); };
$('btn-reset').onclick   = onReset;

/* ── Init ────────────────────────────────────────── */
(async function() {
  await tf.ready();
  log('TensorFlow.js v'+tf.version.tfjs+' — backend: '+tf.getBackend());
  if (tf.getBackend() !== 'webgl') {
    log('⚠ WebGL not available — training will be slow.', '#d29922');
  }
  log('Use Chrome or Edge for best performance.', '#8b949e');
  log('Steps: Load Data → Train Classifier → Train Both Denoisers → Test 5', '#8b949e');
})();
