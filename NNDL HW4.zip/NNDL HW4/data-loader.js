/**
 * data-loader.js
 * Parses MNIST CSV files and builds TensorFlow.js tensors.
 * Based on the original working v1 — minimal changes only.
 */
'use strict';

// Read a File object as a UTF-8 string
function _readFileAsText(file) {
  return new Promise(function(resolve, reject) {
    var reader = new FileReader();
    reader.onload  = function(e) { resolve(e.target.result); };
    reader.onerror = function()  { reject(new Error('FileReader failed')); };
    reader.readAsText(file, 'UTF-8');
  });
}

// Parse CSV text → { labels, pixels, n }
// Handles optional header row automatically.
function _parseCSV(csvText) {
  // Split into non-empty lines
  var lines = csvText.split('\n');
  var data  = [];
  for (var i = 0; i < lines.length; i++) {
    var l = lines[i].trim();
    if (l.length > 0) data.push(l);
  }

  // Skip header: if first column of first row is not a digit, it's a header
  var start = 0;
  if (data.length > 0) {
    var firstCell = data[0].split(',')[0].trim();
    if (!/^\d+$/.test(firstCell)) {
      start = 1; // skip header row
    }
  }

  var n      = data.length - start;
  var labels = new Int32Array(n);
  var pixels = new Float32Array(n * 784);

  for (var i = 0; i < n; i++) {
    var row = data[start + i].split(',');
    labels[i] = parseInt(row[0], 10);
    var off = i * 784;
    for (var j = 0; j < 784; j++) {
      pixels[off + j] = parseFloat(row[j + 1]) / 255.0;
    }
  }

  return { labels: labels, pixels: pixels, n: n };
}

// Build TF tensors from raw arrays
function _buildTensors(labels, pixels, n) {
  var xs   = tf.tensor4d(pixels, [n, 28, 28, 1], 'float32');
  var lbl  = tf.tensor1d(labels, 'int32');
  var ys   = tf.oneHot(lbl, 10).toFloat();
  lbl.dispose();
  return { xs: xs, ys: ys };
}

// PUBLIC: load training CSV
async function loadTrainFromFiles(file) {
  var text = await _readFileAsText(file);
  var parsed = _parseCSV(text);
  console.log('[loader] train rows:', parsed.n);
  return _buildTensors(parsed.labels, parsed.pixels, parsed.n);
}

// PUBLIC: load test CSV
async function loadTestFromFiles(file) {
  var text = await _readFileAsText(file);
  var parsed = _parseCSV(text);
  console.log('[loader] test rows:', parsed.n);
  return _buildTensors(parsed.labels, parsed.pixels, parsed.n);
}

// PUBLIC: split xs/ys into train + val subsets (zero-copy slices)
function splitTrainVal(xs, ys, valRatio) {
  valRatio = valRatio || 0.1;
  var n      = xs.shape[0];
  var nVal   = Math.round(n * valRatio);
  var nTrain = n - nVal;
  return {
    trainXs: xs.slice([0,      0,0,0], [nTrain, 28,28,1]),
    trainYs: ys.slice([0,      0],     [nTrain, 10]),
    valXs:   xs.slice([nTrain, 0,0,0], [nVal,   28,28,1]),
    valYs:   ys.slice([nTrain, 0],     [nVal,   10])
  };
}

// PUBLIC: sample k random rows from test set
function getRandomTestBatch(xs, ys, k) {
  k = k || 5;
  var n = xs.shape[0];
  var idx = [];
  while (idx.length < k) {
    var r = Math.floor(Math.random() * n);
    if (idx.indexOf(r) === -1) idx.push(r);
  }
  var idxT = tf.tensor1d(idx, 'int32');
  var bxs  = tf.gather(xs, idxT);
  var bys  = tf.gather(ys, idxT);
  idxT.dispose();
  return { batchXs: bxs, batchYs: bys, indices: idx };
}

// PUBLIC: add Gaussian noise to a batch  →  clip([0,1])
function addNoise(xs, sigma) {
  sigma = sigma || 0.3;
  return tf.tidy(function() {
    var noise = tf.randomNormal(xs.shape, 0, sigma);
    return xs.add(noise).clipByValue(0, 1);
  });
}

// PUBLIC: draw a [784] or [28,28,1] tensor onto a canvas at `scale` px/pixel
function draw28x28ToCanvas(tensor, canvas, scale) {
  scale = scale || 4;
  var SIZE = 28;
  var W    = SIZE * scale;
  canvas.width  = W;
  canvas.height = W;

  var ctx = canvas.getContext('2d');
  var raw = tensor.dataSync(); // Float32Array [784]

  // Min-max stretch so even partially-trained models produce visible output
  var lo = raw[0], hi = raw[0];
  for (var i = 1; i < raw.length; i++) {
    if (raw[i] < lo) lo = raw[i];
    if (raw[i] > hi) hi = raw[i];
  }
  var rng = hi - lo;

  var img = ctx.createImageData(SIZE, SIZE);
  for (var i = 0; i < SIZE * SIZE; i++) {
    var v = rng > 0.01 ? (raw[i] - lo) / rng : raw[i];
    var b = Math.round(Math.max(0, Math.min(1, v)) * 255);
    img.data[i*4+0] = b;
    img.data[i*4+1] = b;
    img.data[i*4+2] = b;
    img.data[i*4+3] = 255;
  }

  // Draw native 28×28 then scale up with nearest-neighbour
  var off = document.createElement('canvas');
  off.width = off.height = SIZE;
  off.getContext('2d').putImageData(img, 0, 0);
  ctx.imageSmoothingEnabled = false;
  ctx.drawImage(off, 0, 0, W, W);
}
